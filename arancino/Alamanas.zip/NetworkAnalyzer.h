#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include "pin.H"

namespace NetworkAnalyzer {
	VOID Routine(RTN rtn, VOID* v);
	VOID Fini(string base_path);
}